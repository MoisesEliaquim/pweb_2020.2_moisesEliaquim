package br.com.moisesEliaquim.cadpessoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadpessoasMoisesEliaquimApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadpessoasMoisesEliaquimApplication.class, args);
	}

}
