package br.com.moisesEliaquim.cadpessoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadpessoasMoisesEliaquimApplicationTests {

	@Test
	void contextLoads() {
	}

}
